import streamlit as st
import pickle

# Load the model and vectorizer
with open("resume_model.pkl", "rb") as f:
    model = pickle.load(f)

with open("vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

# UI
st.title("📄 AI Resume Checker (Logistic Regression)")

st.write("Paste your resume below to check if it’s suitable for a job role.")

resume_input = st.text_area("✍️ Resume Text", height=250)

if st.button("🔍 Check Suitability"):
    if not resume_input.strip():
        st.warning("Please paste your resume text above.")
    else:
        # Transform the input and predict
        resume_vec = vectorizer.transform([resume_input])
        prediction = model.predict(resume_vec)[0]
        probability = model.predict_proba(resume_vec)[0][prediction]

        if prediction == 1:
            st.success(f"✅ Suitable Resume (Confidence: {probability:.2f})")
        else:
            st.error(f"❌ Not Suitable (Confidence: {probability:.2f})")
